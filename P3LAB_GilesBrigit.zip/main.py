year = int(input(""))

if (year % 4) == 0:

  if (year % 100) == 0:

      if (year % 400) == 0:

          print(str(year) + " - leap year")

      else:

          print(str(year) +" - not a leap year")

  else:

      print(str(year) + " - leap year")

else:

  print(str(year) + " - not a leap year")