first_num = int(input())
second_num = int(input())

if second_num < first_num:
    print("Second integer can't be less than the first.")
else:
    print(first_num, end=" ")
  
    next_num = first_num + 5
    while next_num <= second_num:
        print(next_num, end=" ")
        next_num += 5

    print()  # add a newline character at the end of the output